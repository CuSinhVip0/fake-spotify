<?php

namespace SpotifyLyricsApi;

class SpotifyException extends \Exception
{

}